Add your import statements for View and Game here

document.addEventListener("DOMContentLoaded", () => {
  // Your code here
});