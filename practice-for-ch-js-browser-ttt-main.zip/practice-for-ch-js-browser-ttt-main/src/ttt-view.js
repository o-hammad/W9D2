class View {
  constructor(game, el) {
  }
  
  setupBoard() {
  }
  
  handleClick(e) {
  }

  makeMove(square) {
  }
  
  handleGameOver() {
  }
}

export default View;